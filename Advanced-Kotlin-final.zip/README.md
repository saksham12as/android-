# Advanced Kotlin Assignment
This project is part of my Android Development Specialization provided by Meta on Coursera. In this project I completed my final assignment from the course called "Advanced Programming in Kotlin". I implemented a simple logic for the app that lets user to sort, filter and view dishes.
## Screenshots of the app
<div align="center">
<img width="30%" alt="Screenshot_42" src="https://user-images.githubusercontent.com/92806557/236695085-b1cb2be9-cbbd-49fb-a3bb-4657394d5899.png">
<img width="30%" alt="Screenshot_43" src="https://user-images.githubusercontent.com/92806557/236695088-39ee7f0f-798f-4a9a-ba54-d4ec9c058e73.png">
<img width="30%" alt="Screenshot_41" src="https://user-images.githubusercontent.com/92806557/236695089-9a5ca3dd-b051-4263-83d4-a8b5dc8c70e4.png">
</div>

<div align="center">
<img width="30%" alt="Screenshot_44" src="https://user-images.githubusercontent.com/92806557/236695101-703d00ca-0d7d-4d93-9f29-a04a74f6079c.png">
<img width="30%" alt="Screenshot_40" src="https://user-images.githubusercontent.com/92806557/236695218-deb48184-2d81-4fe6-83d3-02fcf8ad2805.png">
<img width="30%" alt="Screenshot_46" src="https://user-images.githubusercontent.com/92806557/236695160-0057278b-c92b-4b20-a184-a0791bebdbe0.png">
</div>
